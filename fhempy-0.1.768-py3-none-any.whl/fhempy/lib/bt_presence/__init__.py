# Bluetooth presence checker
