# BLE presence checker
